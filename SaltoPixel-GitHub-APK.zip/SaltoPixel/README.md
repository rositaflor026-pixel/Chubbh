# Salto Pixel

Juego de plataformas 2D original para Android.

## Compilar desde GitHub sin PC

1. Sube la carpeta `SaltoPixel` completa a un repositorio de GitHub.
2. En GitHub abre la pestaña **Actions**.
3. Selecciona **Compilar APK**.
4. Pulsa **Run workflow** si no se inició automáticamente.
5. Espera a que termine el trabajo.
6. En la ejecución terminada, baja hasta **Artifacts** y descarga `SaltoPixel-APK`.
7. Dentro del ZIP estará `app-debug.apk`.

El workflow instala Java 17 y Gradle 8.7 y ejecuta `assembleDebug` en un runner de GitHub Actions.
